/* IT EDU — vanilla JS */
(() => {
  'use strict';
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];

  /* ---------- Data-driven cards ---------- */
  const methods = [
    ['🛠️', 'Практикалык окутуу', 'Теорияны практика менен айкалыштыруу', 'Ар бир темадан кийин реалдуу тапшырма аткарасың.'],
    ['📦', 'Project-Based Learning', 'Реалдуу долбоорлор аркылуу үйрөнүү', 'Портфолио түзүп, иш берүүчүгө көрсөтө аласың.'],
    ['🧠', 'Problem-Based Learning', 'Маселени чечүү аркылуу билим алуу', 'Чыныгы маселелерди чечип, ой жүгүртүүнү өнүктүрөсүң.'],
    ['🎛️', 'Interactive Learning', 'Quiz, animation жана интерактивдүү тапшырмалар', 'Билимиңди ошол замат текшерип турасың.'],
    ['👥', 'Peer Learning', 'Студенттердин бири-бирине билим берүүсү', 'Башкага түшүндүрүү — эң мыкты үйрөнүү жолу.'],
    ['🎮', 'Gamification', 'Баллдар, деңгээлдер, badges жана achievements', 'XP жыйнап, деңгээлиңди көтөрүп барасың.']
  ];
  const courses = [
    ['🌐', 'HTML & CSS', 'Баштоочу', 24, 80], ['⚙️', 'JavaScript', 'Орто', 32, 55],
    ['🧱', 'Frontend Development', 'Орто', 40, 35], ['🎨', 'UI/UX Design', 'Баштоочу', 18, 60],
    ['🐍', 'Python', 'Баштоочу', 30, 70], ['🕸️', 'Web Development', 'Жогорку', 48, 20]
  ];
  $('#methodGrid').innerHTML = methods.map(([i, t, d, x]) => `
    <article class="card reveal"><span class="ico">${i}</span><h3>${t}</h3><p>${d}</p>
    <div class="extra">${x}</div>
    <button class="more" aria-expanded="false">Кененирээк</button></article>`).join('');
  $('#courseGrid').innerHTML = courses.map(([i, t, l, n, p]) => `
    <article class="card reveal"><span class="ico">${i}</span><h3>${t}</h3>
    <p><span class="tag">${l}</span> &nbsp;${n} сабак</p>
    <div class="bar-track"><div class="fill" data-w="${p}"></div></div>
    <small>${p}%</small><br><br><a href="#contact" class="btn btn-primary">Курска өтүү</a></article>`).join('');

  /* ---------- Mobile menu ---------- */
  const burger = $('#burger'), menu = $('#menu');
  const closeMenu = () => { menu.classList.remove('open'); burger.setAttribute('aria-expanded', 'false'); };
  burger.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    burger.setAttribute('aria-expanded', open);
  });
  $$('a', menu).forEach(a => a.addEventListener('click', closeMenu));

  /* ---------- Theme toggle (remembered) ---------- */
  const root = document.documentElement;
  try { root.dataset.theme = localStorage.getItem('theme') || 'dark'; } catch (e) {}
  $('#themeBtn').addEventListener('click', () => {
    root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
    try { localStorage.setItem('theme', root.dataset.theme); } catch (e) {}
  });

  /* ---------- Reveal, progress bars, counters ---------- */
  const count = el => {
    const to = +el.dataset.to; let n = 0;
    const step = () => { n += Math.ceil(to / 40); el.textContent = Math.min(n, to); if (n < to) requestAnimationFrame(step); };
    step();
  };
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    const t = e.target; t.classList.add('in');
    $$('.fill', t).forEach(f => f.style.width = f.dataset.w + '%');
    if (t.classList.contains('fill')) t.style.width = t.dataset.w + '%';
    if (t.classList.contains('count')) count(t);
    io.unobserve(t);
  }), { threshold: .2 });
  $$('.reveal, .count, .hero .stats').forEach(el => io.observe(el));
  $$('.timeline li').forEach((li, i) => li.style.transitionDelay = i * 120 + 'ms'); // staggered steps

  /* ---------- Expand card details & FAQ ---------- */
  document.addEventListener('click', e => {
    const more = e.target.closest('.more');
    if (more) {
      const card = more.closest('.card'), o = card.classList.toggle('open');
      more.setAttribute('aria-expanded', o);
      more.textContent = o ? 'Жабуу' : 'Кененирээк';
    }
    const q = e.target.closest('.faq-item button');
    if (q) q.setAttribute('aria-expanded', q.parentElement.classList.toggle('open'));
  });

  /* ---------- Scroll: active link, back-to-top ---------- */
  const links = $$('.menu a'), secs = links.map(a => $(a.getAttribute('href')));
  const toTop = $('#toTop');
  addEventListener('scroll', () => {
    const y = scrollY + 120;
    secs.forEach((s, i) => links[i].classList.toggle('active', s && s.offsetTop <= y && s.offsetTop + s.offsetHeight > y));
    toTop.classList.toggle('show', scrollY > 600);
  }, { passive: true });
  toTop.addEventListener('click', () => scrollTo({ top: 0, behavior: 'smooth' }));

  /* ---------- Form validation ---------- */
  const form = $('#form'), status = $('#status');
  form.addEventListener('submit', e => {
    e.preventDefault();
    let ok = true;
    $$('input,textarea', form).forEach(f => {
      const bad = !f.value.trim() || (f.type === 'email' && !/^\S+@\S+\.\S+$/.test(f.value));
      f.classList.toggle('err', bad); f.setAttribute('aria-invalid', bad); if (bad) ok = false;
    });
    status.textContent = ok ? '✅ Рахмат! Билдирүүңүз жөнөтүлдү.' : '⚠️ Бардык талааларды туура толтуруңуз.';
    if (ok) form.reset();
  });
})();
